=== Plugin Name ===
Contributors: chiragkalani
Tags: SMS, SMS Gateway Plugin, Wordprss SMS Plugin
Requires at least: 3.3.2
Tested up to: 1.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP-SendSMS is Wordpress Plugin for allowing user to send SMS using SMS Gateway. 

== Description ==

WP-SendSMS Wordpress Plugin is for people of whom want to add freature of Sending Free SMS from their Wordpress Site. 

This Plugin allows site owner to add SMS Gateway in Plugin Setting Page. It also have many different option for 

captcha, allow sending sms without login etc.

Features of Plugin:

1. Editable SMS Gateway Integration in plugin setting Page.
2. Sender Id Setting
3. Remove bad Words or not
4. Maximum Characters in one Message
5. Captcha code enable/disable and Also can set Captcha Size and Number of Character
6. Add Extra Confirmation page while sending SMS
7. Allow or Not to allow users to send SMS without Login
8. Show Custom Response or Original Response from SMS Gateway API


You can use shortcode in Page or Post content as below: 

[wpsms_form]


For Further Detail Information And Installation Vist http://thedigilife.com/wordpress-sms-plugin-wp-sendsms/

This is version 1.0. I will be keep Updating this plugin for adding new features. 

Future Features That I am going to include in next versions

- Custom notification in front side SMS Form
- Support Multiple API for sending SMS
- Limit Per day SMS Sending per USER or per IP
- Automatically Switching API on number of sent SMS
- Exporting Facility for Sent SMS
- Exporting Facility for NUmber
- User Registration
- Widget and Display function for SMS Form

Please Send your Suggestion for future enhancement suggestion at http://thedigilife.com/wordpress-sms-plugin-wp-sendsms/



== Installation ==

By one of two way you can install this plugin Manual and Automatically. Manual Way requires FTP Access. 

Below are the Manual Steps

1. Download 'WP-SendSMS' and Upload it to the 'wp-content/plugins' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Create page for Sending SMS and Place showcode [wpsms_form]

Below are the steps for automatic way

1. In wprdpress admin, go to plugin and Click on 'Add New'
2. Search For the plugin 'WP-SendSMS'
3. Locate the Plugin and Click on Install
4. Create page for Sending SMS and Place showcode [wpsms_form]

== Frequently Asked Questions ==

NO FAQ

An answer to that question.

No Answer


== Screenshots ==

Visit http://thedigilife.com/wordpress-sms-plugin-wp-sendsms/

== Changelog ==

= 1.0 =

This is first Version

= 1.1 =

Added admin side multiple number seding sms features
Fixed bugs

== Upgrade Notice ==
1.0
No Upgrades
1.1
Added admin side multiple number seding sms features
Fixed bugs

== Arbitrary section ==
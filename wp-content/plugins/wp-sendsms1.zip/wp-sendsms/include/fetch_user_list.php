<?php
	require_once('../../../../wp-load.php'); 
	$cat_id = ($_REQUEST["cat_id"] <> "") ? trim($_REQUEST["cat_id"]) : "";
	//echo $cat_id;
	if ($cat_id <> "") {
		global $wpdb;
		$table_name = $wpdb->prefix.'wp_subscriber';
		$sql = "select * from wp_subscriber inner join wp_subscription on wp_subscriber.id = wp_subscription.aid where sname='$cat_id'";
		//var_dump($sql);
		//$wpdb->flush();
		$data = $wpdb->get_results($sql);
		//print_r($data);
		//var_dump($result);
		?>
			
		<?php
		if(count($data) > 0){
			?>
				
				<label class="col-xs-3">Select Subscribers</label>
				<div class="col-xs-5">
					<select name="adminmobile[]" id="adminmobile" multiple="multiple" class="selectpicker">
						<?php foreach($data as $key){?>
							<?php echo $_SESSION['adminmobile'] ?>
							<option value="<?php echo $key->mobile; ?>"><?php echo $key->mobile ?></option>
						<?php }?>
					</select>
				</div>
				<script type="text/javascript">

				$(function () {
				            $('#adminmobile').multiselect({
				                includeSelectAllOption: true
				            });
				            // $('.btn-primary').click(function () {
				            //     var selected = $("#multiSelect option:selected");
				            //     var message = "";
				            //     selected.each(function () {
				            //         message += $(this).text() + " " + $(this).val() + "\n";
				            //     });
				            //     alert(message);
				            // });
				        });
				</script>
				
			<?php	
		}	
		
	}
	
?>
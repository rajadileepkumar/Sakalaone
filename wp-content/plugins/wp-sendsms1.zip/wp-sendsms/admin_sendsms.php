<div class="wrap">
<div id="icon-options-general" class="icon32"><br></div>
<h2>Send SMS</h2>
<p>Here you can send sms to any number. This can be used for promotion, Customer notification, Information passing etc.</p>
<?php global $admin_sms_response;  if($admin_sms_response != '') { ?>
<div id="message" class="updated"><p><?php echo $admin_sms_response; 
$admin_sms_response=''; ?></p></div>
<?php } ?>
<form action="" method="post" id="wp-sms-form" role="form" class="form-horizontal">
		
		<div class="col-xs-12">
			<div class="form-group">
				<label class="col-xs-3">Select Subscription List</label>
				<div class="col-xs-5">
					<select name="multiSelectSubscription" id="multiSelectSubscription" onchange="print_name(this)" class="selectpicker">
						<option value="">Select Category List</option>
						<?php
		            		global $wpdb;
		            		$table_name = $wpdb->prefix.'subscription_category';
		            		echo $table_name;
		            		$sql = "select subscription_cat_name from $table_name";
		         			$data = $wpdb->get_results($sql);
		         			foreach ($data as $key) {
		 						echo "<option value='".$key->subscription_cat_name."'>".$key->subscription_cat_name."</option>";
		 					}		
						?>
					</select>
				</div>
			</div>
			<div class="form-group" id="output1">
			</div>
			<div class="form-group">
				<label class="col-xs-3">Message</label>
				<div class="col-xs-5">
					<textarea name="adminmessage" id="adminmessage" rows="5" cols="50"><?php echo $_SESSION['adminmessage'] ?></textarea><?php if(get_option('remove_bad_words')) {
						echo "<p>Note: Bad Words in the message will be removed</p>";
					} ?>
				</div>
			</div>
			<input type="submit" id="submit" value="Send SMS" class="btn btn-primary"/>	
		</div>
		<?php wp_nonce_field('admin_send_sms','admin_send_sms_nonce'); ?>
	</form>
</div>
<script type="text/javascript">
	function print_name(sel){
        //var ajaxurl = <?php plugin_dir_url(__FILE__ ).'include/fetch_user_list.php';?>
        //console.log(ajaxurl);
        $("#output1").html("");
        var cat_id = sel.options[sel.selectedIndex].value;
        console.log(cat_id);
        var url="<?php echo plugin_dir_url(__FILE__).'include/fetch_user_list.php'?>";
        //alert(url);
        if(cat_id.length>0){
            $.ajax({
                type:"POST",
                url:url,
                data:"cat_id="+cat_id,
                cache:false,
                success:function(html){
                    $("#output1").html(html);
                }

            });
        }
    }
</script>
<?php
/**
* Plugin Name: Payment History
* Plugin URI: https://www.github.com/rajadileepkumar
* Description: Payment History Of Subscribers
* Version: 1.0.0
* Author: Raja Dileep Kumar
* Author URI: https://github.com/rajadileepkumar
* License: GPL2
*/
if(!class_exists('Payment_History')){
    class Payment_History{
    	public function __construct()
        {
            add_action('admin_menu', array($this,'payment_history_menu'));
        }

        public function payment_history_menu(){
        	add_menu_page('Payment History', 'Payment History', 'manage_options', 'payment_history', array($this,'payment_history_page'));
        }
        public function payment_history_page(){
        	echo "Hello World";
        } 		
    }
}
$obj = new Payment_History();

?>
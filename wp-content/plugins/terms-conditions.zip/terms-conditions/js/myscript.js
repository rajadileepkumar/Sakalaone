//alert(object_name.some_string);
var $ = jQuery.noConflict();
//$('#myModal').modal();

// $(object_name.some_string).modal(
// 			{show:true,}
// 		);
<?php
/**
* Plugin Name: Profile Builder
* Plugin URI: https://www.github.com/rajadileepkumar
* Description: Resume Builder Page for Subscribers
* Version: 1.0.0
* Author: Raja Dileep Kumar
* Author URI: https://github.com/rajadileepkumar
* License: GPL2
*/
if(!class_exists('Profile_Builder')){
    class Profile_Builder{
        public function __construct()
        {
            add_action('admin_menu', array($this,'profile_users_menu'));
        }

        public function profile_users_menu() {
            add_menu_page('Profile Page', 'Resume Builder', 'subscriber', 'profile_builder', array($this,'profile_builder_page'),'dashicons-id-alt');
            add_menu_page('Documents', 'Documents', 'subscriber', 'download_builder', array($this,'download_builder_page'),'dashicons-portfolio');
        }

        public function profile_builder_page(){
            global $current_user;
            $user_id = get_current_user_id();
            if(isset($_POST['profile'])){
                $firstName = $_POST['firstName'];
                $lastName = $_POST['lastName'];
                $fatherName = $_POST['fatherName'];
                $motherName = $_POST['motherName'];
                $dob = $_POST['dob'];
                $email = $_POST['email'];
                $address = $_POST['address'];
                $yopSslc = $_POST['yopSslc'];
                $regNumberSslc= $_POST['regNumberSslc'];
                $perSslc = $_POST['perSslc'];
                $yopPuc = $_POST['yopPuc'];
                $regNumberPuc = $_POST['regNumberPuc'];
                $perPuc = $_POST['perPuc'];
                $yopG = $_POST['yopG'];
                $regNumberG = $_POST['regNumberG'];
                $perG = $_POST['perG'];
                $yopPg = $_POST['yopPg'];
                $regNumberPg = $_POST['regNumberPg'];
                $perPg = $_POST['perPg'];
                $other1 = $_POST['other1'];
                $other2 = $_POST['other2'];
                $cDate = $_POST['cDate'];
                $place = $_POST['place'];
                $signature = $_POST['signature'];

                $p_profile = array(
                    'firstName' => $firstName,
                    'lastName' => $lastName,
                    'fatherName' => $fatherName,
                    'motherName' => $motherName,
                    'dob' => $dob,
                    'email' => $email,
                    'address' => $address,
                    'yopSslc' => $yopSslc,
                    'regNumberSslc' => $regNumberSslc,
                    'perSslc' => $perSslc,
                    'yopPuc' => $yopPuc,
                    'regNumberPuc' => $regNumberPuc,
                    'perPuc' => $perPuc,
                    'yopG' => $yopG,
                    'regNumberG' => $regNumberG,
                    'perG' => $perG,
                    'yopPg' => $yopPg,
                    'regNumberPg' => $regNumberPg,
                    'perPg' => $perPg,
                    'other1' => $other1,
                    'other2' => $other2,
                    'place' => $place,
                    'cDate' => $cDate,
                    'signature' => $signature
                );
                echo $user_id;
                foreach ($p_profile as $key => $value){
                    update_user_meta($user_id,$key,$value);
                }
            }
            ?>
            <div class="wrap" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
                    <h2>Profile Page</h2>
                    <div class="printfriendly pf-alignleft"><a href="#" rel="nofollow" onclick="window.print(); return false;" class="noslimstat"><img style="border:none;-webkit-box-shadow:none; box-shadow:none;" src="http://cdn.printfriendly.com/pf-button.gif" alt="Print Friendly"></a></div>
                    <form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post">
                        <table class="form-table">
                            <tr class="user-first-name-wrap">
                                <th>
                                    <label for="firstName">First Name</label>
                                </th>
                                <td>
                                    <input type="text"class="regular-text" name="firstName" id="firstName" value="<?php echo $current_user->firstName?>">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th>
                                    <label for="lastName">Last Name</label>
                                </th>
                                <td>
                                    <input type="text" name="lastName" id="lastName" class="regular-text" value="<?php echo $current_user->lastName?>">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th>
                                    <label for="fatherName">Father's Name</label>
                                </th>
                                <td>
                                    <input type="text" name="fatherName" id="fatherName" class="regular-text" value="<?php echo $current_user->fatherName?>">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th>
                                    <label for="motherName">Mother's Name</label>
                                </th>
                                <td>
                                    <input type="text" name="motherName" id="motherName" class="regular-text" value="<?php echo $current_user->motherName?>">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th>
                                    <label for="dob">DOB</label>
                                </th>
                                <td>
                                    <input type="date" name="dob" id="dob" class="regular-text" value="<?php echo $current_user->dob?>">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th>
                                    <label for="phoneNumber">Ph Number</label>
                                </th>
                                <td>
                                    <input type="text" name="phoneNumber" id="phoneNumber" class="regular-text" value="<?php echo $current_user->user_login?>" disabled>
                                </td>
                                <th>
                                    <label for="email">Email</label>
                                </th>
                                <td>
                                    <input type="email" name="email" id="email" class="regular-text" value="<?php echo $current_user->email?>">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th>
                                    <label for="address">Address</label>
                                </th>
                                <td>
                                    <textarea cols="35" rows="5" name="address" id="address"><?php echo $current_user->address?></textarea>
                                </td>
                            </tr>
                        </table>
                        <h2>Accdemic Details</h2>
                        <table class="form-table">
                            <tr>
                                <td></td>
                                <th style="text-align:center">
                                    <label>College Name</label>
                                </th>    
                                <th style="text-align:center">
                                    <label>Year Of Pass</label>
                                </th>    
                                <th style="text-align:center">
                                    <label>Percentage % </label>
                                </th>    
                            </tr>
                            <tr class="user-first-name-wrap" width="100%">
                                <th>
                                    <label for="sslc">SSLC</label>
                                </th>
                                <td width="33.33%">
                                    <input type="text" name="yopSslc" id="yopSslc" class="regular-text" value="<?php echo $current_user->yopSslc?>" style="width:20em;">
                                </td>
                                <td width="33.33%">
                                    <input type="text" name="regNumberSslc" id="regNumberSslc" class="regular-text" value="<?php echo $current_user->regNumberSslc?>" style="width:20em;">
                                </td>
                                <td width="33.33">
                                    <input type="text" name="perSslc" id="perSslc" class="regular-text" value="<?php echo $current_user->perSslc?>" style="width:20em;">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th><label for="puc">PUC</label></th>
                                <td>
                                    <input type="text" name="yopPuc" id="yopPuc" class="regular-text" value="<?php echo $current_user->yopPuc?>" style="width:20em;">
                                </td>    
                                <td>
                                    <input type="text" name="regNumberPuc" id="regNumberPuc" class="regular-text" value="<?php echo $current_user->regNumberPuc?>" style="width:20em;">
                                </td>
                                <td>    
                                    <input type="text" name="perPuc" id="perPuc" class="regular-text" value="<?php echo $current_user->regNumberPuc?>" style="width:20em;">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th><label for="grdu">Graduation</label></th>
                                <td>
                                    <input type="text" name="yopG" id="yopG" class="regular-text" value="<?php echo $current_user->yopG?>" style="width:20em;">
                                </td>    
                                <td>
                                    <input type="text" name="regNumberG" id="regNumberG" class="regular-text" value="<?php echo $current_user->yopG?>" style="width:20em;">
                                </td>
                                <td>      
                                    <input type="text" name="perG" id="perG" class="regular-text" value="<?php echo $current_user->yopG?>" style="width:20em;">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th><label for="Pgrdu">PG</label></th>
                                <td>
                                    <input type="text" name="yopPg" id="yopPg" class="regular-text" value="<?php echo $current_user->yopPg?>" style="width:20em;">
                                </td>    
                                <td>
                                    <input type="text" name="regNumberPg" id="regNumberPg" class="regular-text" value="<?php echo $current_user->regNumberPg?>" style="width:20em;">
                                </td>
                                <td>      
                                    <input type="text" name="perPg" id="perPg" class="regular-text" value="<?php echo $current_user->perPg?>" style="width:20em;">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th>
                                    <label for="other1">Other1</label></th>
                                <td>
                                    <input type="text" name="other1" id="other1" class="regular-text"  value="<?php echo $current_user->other1?>">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th>
                                    <label for="other2">Other2</label></th>
                                <td>
                                    <input type="text" name="other2" id="other2" class="regular-text" value="<?php echo $current_user->other2?>">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th>
                                    <label for="place">Place</label></th>
                                <td>
                                    <input type="text" name="place" id="place" class="regular-text" value="<?php echo $current_user->place?>">
                                </td>
                            </tr>
                            <tr class="user-first-name-wrap">
                                <th><label for="cDate">Date</label></th>
                                <td>
                                    <input type="date" name="cDate" id="cDate" class="regular-text" value="<?php echo $current_user->cDate?>">
                                </td>
                            </tr>
                        </table>
                        <p class="submit">
                            <input type="submit" value="Update Profile" class="button button-primary" name="profile">
                        </p>
                    </form>
                </div>
            <?php
        }

        public function download_builder_page(){
            $new = new WP_Query('post_type=cmdm_page');
            ?>
            <div class="wrap">
            <h2>All Downloads</h2>

            <p><a target="_blank" href="<?php echo home_url('/cmdownload/add/')?>" class="button button-primary">Add New</a></p>
            <table class="abc" border="2">
                <tr><td>Id</td><td>File Name</td><td>Download Link</td><td>Content</td></tr>
                <?php
                while ($new->have_posts()) : $new->the_post();
                    ?>
                        <tr>
                            <td><?php the_ID();?></td>
                            <td><?php the_title();?></td>
                            <td><a href="<?php the_guid()?>" target="_blank"><?php the_title()?></a></td>
                            <td><?php the_content();?></td>
                        </tr>
                    <?php
                    endwhile;
            ?></table></div><?php
        }
    }
}
$obj = new Profile_Builder();
?>